import { Component } from '@angular/core';
import { DemoserviceService } from '../demoservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-diet-plan',
  templateUrl: './create-diet-plan.component.html',
  styleUrls: ['./create-diet-plan.component.css']
})
export class CreateDietPlanComponent {

  constructor (private dataSrc:DemoserviceService, private router:Router){
    
  }

  gender:any;
  age:any;
  height:any;
  weight:any;
  isExercise:any;
  uId:any;


  week_day:any;
  meal_type:any;
  food_item:any;
  quantity:any;
  calories_1:any;
  fats_1:any;
  proteins_1:any;

  saveProfile(){
    let data={
      gender:this.gender,
      age:this.age,
      height:this.height,
      weight:this.weight,
      isExercise:this.isExercise,
      uId:this.uId
    }
    if(data.gender && data.age && data.height && data.weight && data.isExercise && data.uId){
      this.dataSrc.userProfileDetails(data).subscribe((x)=>{console.log(x)});
      //this.router.navigateByUrl("/");

    }
    else{
      alert("Enter all the details");
    }
  }

  saveFoodItem(){
    let data={
      week_day:this.week_day,
      meal_type:this.meal_type,
      food_item:this.food_item,
      quantity:this.quantity,
      calories_1:this.calories_1,
      fats_1:this.fats_1,
      proteins_1:this.proteins_1

    }

    if(data.week_day && data.meal_type && data.food_item && data.quantity && data.calories_1 && data.fats_1 && data.proteins_1){
      this.dataSrc.saveFoodChoice(data).subscribe((x)=>{console.log(x)});
      //this.router.navigateByUrl("/");

    }
    else{
      alert("Enter all the details");
    }
  }

}
