import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DemoserviceService {

  constructor(private http:HttpClient) { }

  registerUser="http://localhost:8080/userDetails";
  checkLogin="http://localhost:8080/checklogin";
  profile="http://localhost:8080/userProfile";
  fooditemssave="http://localhost:8080/foodChoice";

  postRegister(data:any){
    return this.http.post(this.registerUser, data);

  }

  postCheckLogin(data:any){
    console.log('Success');
    return this.http.post(this.checkLogin, data);
    
  }

  userProfileDetails(data:any){
    console.log('Success');
    return this.http.post(this.profile, data);

  }

  saveFoodChoice(data:any){
    console.log('Success');
    return this.http.post(this.fooditemssave, data)
  }
  
}
