import { Component } from '@angular/core';

@Component({
  selector: 'app-view-diet-plan',
  templateUrl: './view-diet-plan.component.html',
  styleUrls: ['./view-diet-plan.component.css']
})
export class ViewDietPlanComponent {

}
